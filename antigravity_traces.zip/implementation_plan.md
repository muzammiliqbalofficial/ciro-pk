# CIRO-PK: Crisis Intelligence & Response Orchestrator
## Formal Workplan & Architectural Design

CIRO-PK is a multi-agent orchestration framework built for the **#AISeekho 2026 Google Antigravity Hackathon (Challenge 3)**. It is designed to ingest multi-source crisis signals, classify simultaneous incidents, resolve resource conflicts, debunk rumors, orchestrate emergency response chains, and alert stakeholders.

This document serves as the formal **WORKPLAN** and **TASK_PLAN** for the project, followed by a code review and proposed enhancements for `backend/main.py`.

---

## 1. Formal Workplan

### Goal
Implement a highly resilient, multi-agent orchestrator for crisis management in Islamabad using Vertex AI (Google Agent Platform). The system must process heterogeneous inputs (social media, weather data, physical sensors), separate true threats from false alarms, allocate constrained resources optimally, and generate targeted alerts in under 35 seconds.

### The Agent Pipeline
CIRO-PK structures its decision-making through **8 distinct agent roles** running in a coordinated 3-stage lifecycle:

```mermaid
graph TD
    %% Source Ingestion
    Signals[Multi-Source Signals: Social, Sensor, Weather, Maps] --> SF[SIGNAL_FUSION Agent]
    SF --> Stage1[STAGE 1: Parse & Validate]

    %% Stage 1 Parallel Execution
    subgraph Stage1 [STAGE 1: Ingestion & Verification]
        CLASSIFIER[CLASSIFIER Agent<br/>Vertex AI + report_classified_crises]
        VERIFIER[VERIFIER Agent<br/>Vertex AI + Sensor Cross-Check]
    end

    Stage1 --> Stage2[STAGE 2: Predict & Allocate]

    %% Stage 2 Parallel Execution
    subgraph Stage2 [STAGE 2: Projection & Resource Assignment]
        PREDICTOR[PREDICTOR Agent<br/>Severity & Spread Modeling]
        ALLOCATOR[ALLOCATOR Agent<br/>Vertex AI + allocate_emergency_resources]
    end

    Stage2 --> Stage3[STAGE 3: Action & Synthesis]

    %% Stage 3 Execution
    subgraph Stage3 [STAGE 3: Orchestration & Communication]
        ORCHESTRATOR[ORCHESTRATOR Agent<br/>5-Step Action Chain & Side-Effects]
        NOTIFIER[NOTIFIER Agent<br/>Multilingual Stakeholder Alerts]
        REASONER[GEMINI_REASONER Agent<br/>Senior Synthesis & Global Log]
    end

    Stage3 --> Output[Unified Response Payload]
```

#### Detailed Agent Breakdown
1. **SIGNAL_FUSION (Ingestion & Filtering)**:
   - *Role*: Ingests raw data streams, performs deduplication, credibility scoring, and integrates real-time weather information (OpenWeatherMap API).
2. **CLASSIFIER (Function-Calling Agent)**:
   - *Role*: Detects and categorizes active, simultaneous crises.
   - *Tool*: `report_classified_crises` — extracts structured metrics (type, location, severity, confidence, classification summary).
3. **VERIFIER (Misinformation Debunker)**:
   - *Role*: Cross-checks unverified rumors against live, high-credibility physical sensors (e.g. NDMA telemetry) to prevent resource diversion to false alarms.
4. **PREDICTOR (Severity & Spread Modeling)**:
   - *Role*: Predicts flood boundary expansion, vulnerable population sizes, and peak impact timestamps based on live weather data.
5. **ALLOCATOR (Function-Calling Agent)**:
   - *Role*: Balances constrained municipal resources (ambulances, rescue teams, police units, water tankers) between competing incidents.
   - *Tool*: `allocate_emergency_resources` — enforces a strict **20% emergency reserve** constraint and prioritizes life-threatening scenarios.
6. **ORCHESTRATOR (Response Pipeline Simulator)**:
   - *Role*: Triggers and sequences response steps, assessing operational side effects (e.g. traffic congestion on alternate routes).
7. **NOTIFIER (Targeted Communicator)**:
   - *Role*: Dispatches multilingual, audience-specific emergency messages across channels (SMS, radio, dashboard alerts) in English and Roman Urdu.
8. **GEMINI_REASONER (Senior Synthesizer)**:
   - *Role*: Synthesizes all intermediate decisions and outputs into a single cohesive incident trace.

---

### Tools Used
CIRO-PK utilizes Gemini **Function Calling (Tools)** to interface with structured APIs and output type-safe telemetry:
- `report_classified_crises`: Extracts structured fields for multiple simultaneous emergencies.
- `allocate_emergency_resources`: Resolves resource constraints under strict business rules (priority ranks, minimum reserves).

---

### Google Agent Platform SDK Integration
- **SDK**: `google-genai` (v1.0.0+)
- **Model**: `gemini-3.1-flash-lite-preview` (Vertex AI mode: `vertexai=True`, project: `iro-pk-backend`, location: `global`)
- **Key Configs**:
  - Uses `types.GenerateContentConfig` to define tools, enforce function calling mode (`mode="ANY"`), and control parameters like `temperature=0.1` for deterministic reasoning.

---

### Recovery & Fallback Strategy (Tiered Resilience)
To guarantee a "never-breaks" demo during hackathon evaluations, CIRO-PK implements 4 layers of fallbacks:

| Layer | Context | Action |
| --- | --- | --- |
| **Tier 1: Vertex AI Live** | Target Environment | Connects to `gemini-3.1-flash-lite-preview` via Google Vertex AI global endpoint. |
| **Tier 2: AI Studio Dev** | Vertex Outage/Local API Key | Falls back to `gemini-2.5-flash` using `GEMINI_API_KEY` environment variable. |
| **Tier 3: Backend Resilient** | API Outage / Rate Limits | Python try-except blocks capture exceptions per agent and seamlessly swap in deterministic simulated values, continuing the pipeline. |
| **Tier 4: Frontend Local** | Backend Offline | Both the React Web Dashboard and Expo Mobile App catch connection failures and run a complete client-side simulated trace. |

---

## 2. Task Plan: Crisis Response Workflow

During a typical run cycle, the orchestrator executes the following tasks:

- `[ ]` **Ingest & Fuse Signals**:
  - Merge the 8 initial signals (citizen reports, NDMA logs, traffic status).
  - Call OpenWeatherMap API to retrieve live Islamabad temperature, wind, and precipitation. Append this as a live signal.
- `[ ]` **Parallel Stage 1 (Validate & Classify)**:
  - Submit signals to `CLASSIFIER` function-calling agent to extract details on C1 (Flood) and C2 (Accident).
  - Submit S3 rumor to `VERIFIER` agent to cross-check against NDMA sensor level. Debunk Rawal Dam breach and log the false alarm.
- `[ ]` **Parallel Stage 2 (Analyze & Allocate)**:
  - Submit classification data to `PREDICTOR` agent to estimate flood spread radius, vulnerable population size, and peak impact.
  - Submit severity levels to `ALLOCATOR` function-calling agent. Reserve 2 ambulances (20% of 8) and distribute the remaining 6 based on severity.
- `[ ]` **Execute Coordinated Action Chain**:
  - Step 1: Dispatch emergency units to Faizabad (accident) and G-10 (flood).
  - Step 2: Route traffic away from Kashmir Highway via Margalla Road/Murree Road.
  - Step 3: Alert PIMS Hospital trauma unit.
  - Step 4: Disconnect electricity grids at G-10 via IESCO substation to prevent electrocution.
  - Step 5: Broadcast Roman Urdu evacuation alerts to G-10/G-9 residents.
- `[ ]` **Parallel Stage 3 (Simulate Side Effects & Synthesize)**:
  - Submit actions to `ORCHESTRATOR` to evaluate rerouting congestion percentages.
  - Submit all logs to `GEMINI_REASONER` for final synthesis summary.
  - Collate all JSON outputs and return to frontend client.

---

## 3. Code Review: backend/main.py

After analyzing [backend/main.py](file:///C:/Users/Hp/.gemini/antigravity/scratch/ciro-pk/backend/main.py), we identified several key improvements to simplify the Google Agent Platform integration, increase reliability, and reduce request latency:

### Improvement 1: Cache `genai.Client` Globally
Currently, every function call (`_gemini`, `agent_classify_with_tools`, `agent_allocate_with_tools`) instantiates a new `genai.Client` object:
```python
def get_client() -> genai.Client:
    api_key = os.environ.get("GEMINI_API_KEY")
    if api_key:
        return genai.Client(api_key=api_key)
    return genai.Client(vertexai=True, project=PROJECT, location=LOCATION)
```
**Rationale**: Instantiating a client on every call forces Python to rebuild the configuration and establish new HTTP connection pools. By caching the client globally, we reuse connections, reducing overall cycle latency by ~1-2 seconds across 6 sequential calls.

### Improvement 2: Use Native Python Functions for Tool Declarations
The current code manually builds verbose JSON schema-like objects using `types.Tool` and `types.FunctionDeclaration`:
```python
CLASSIFY_TOOL = types.Tool(function_declarations=[
    types.FunctionDeclaration(
        name="report_classified_crises",
        description="...",
        parameters=types.Schema(
            type=types.Type.OBJECT,
            properties={...},
            required=[...]
        )
    )
])
```
**Rationale**: The new `google-genai` SDK allows passing standard Python functions directly to `tools`. The SDK automatically generates the JSON schema from the function's parameter names, Python type hints, and docstrings. This significantly reduces boilerplate and prevents syntax mismatches.

### Improvement 3: Structured Outputs (`response_schema`)
Both `CLASSIFIER` and `ALLOCATOR` are function-calling agents whose sole purpose is to extract structured JSON data from prompts. They do not execute real tools.
**Rationale**: Gemini supports **Structured Outputs** directly using the `response_schema` parameter in `types.GenerateContentConfig`. Using structured outputs is cleaner than forcing a fake function call with `mode="ANY"`, as the model natively outputs JSON matching the schema without needing to parse function candidates. We will show both approaches, but recommend upgrading to Structured Outputs where appropriate.

---

## 4. Antigravity-Style Workplan Header for `backend/main.py`

To track implementation details, architecture, and task statuses directly in code, we propose adding the following Antigravity-style workplan comment block at the very top of `backend/main.py`:

```python
# ==============================================================================
# CIRO-PK: Crisis Intelligence & Response Orchestrator
# Google Antigravity Hackathon 2026 - Challenge 3 Submission Backend
#
# ARCHITECTURE WORKPLAN:
# 1. SIGNAL_FUSION  -> Ingest weather, maps, social signals (Roman Urdu & English)
# 2. CLASSIFIER     -> [Tool Calling] Parse simultaneous incidents (Flood & Accident)
# 3. VERIFIER       -> Cross-reference Rawal Dam rumor against live NDMA sensor data
# 4. PREDICTOR      -> Models flood radius expansion and peak impact window
# 5. ALLOCATOR      -> [Tool Calling] Resolve ambulance/police resource conflicts
# 6. ORCHESTRATOR   -> Exec 5-step action chain, evaluate secondary traffic routing
# 7. NOTIFIER       -> Dispatch multilingual stakeholder alerts (SMS/Radio/Dashboard)
# 8. GEMINI_REASON  -> Synthesize senior executive summary of the cycle
#
# GOOGLE AGENT PLATFORM SDK COMPLIANCE:
# - Client: google-genai SDK with global connection reuse
# - Model: gemini-3.1-flash-lite-preview (Vertex AI) / gemini-2.5-flash (AI Studio fallback)
# - Tooling: Function-Calling configuration + JSON schemas
#
# SYSTEM RESILIENCE (FOUR-TIERED FALLBACKS):
# - Tier 1: Vertex AI Global Endpoint
# - Tier 2: AI Studio Developer API Key Fallback
# - Tier 3: In-Memory Resilient Python Exception Catching & Deterministic Simulation
# - Tier 4: Client-side (Vite & Expo Native) Local Fallback
# ==============================================================================
```

---

## 5. Verification Plan

We will verify our changes using the following strategies:

### Automated Tests
1. **Unit tests for client caching**: Ensure that successive calls to `get_client()` return the exact same instance.
2. **API Endpoint validation**: Curl `/api/analyze` and verify the structure of the JSON payload.
   ```powershell
   Invoke-RestMethod -Uri "http://localhost:8080/api/analyze" -Method Post -ContentType "application/json" -Body '{"signals": []}'
   ```
3. **Health Check validation**:
   ```powershell
   Invoke-RestMethod -Uri "http://localhost:8080/health" -Method Get
   ```

### Manual Verification
1. Run the Flask backend locally and trigger the simulation from the React Web Dashboard to verify visual trace logs and marker rendering.
2. Verify that Roman Urdu messages and debunker alerts match expectations.
