# CIRO-PK: Official Demo Video Script
**Target Duration**: ~4 minutes  
**Format**: Screen recording (Web Dashboard + Mobile App) with English Voiceover.

---

## Act 1: Introduction & Problem Statement (0:00 - 0:45)

| Time | Visual on Screen | Voiceover (Audio) |
| --- | --- | --- |
| **0:00 - 0:15** | • Show the **Vite Command Center Dashboard** in standby state.<br/>• Highlight the title **CIRO-PK (Crisis Intelligence & Response Orchestrator)**.<br/>• Zoom into the Islamabad Map. | *"Hello everyone! We are Team Antigravity, presenting **CIRO-PK**—the Crisis Intelligence and Response Orchestrator built for the #AISeekho 2026 Hackathon, Challenge 3.*<br/><br/>*Our mission is to replace slow, fragmented, and reactive emergency systems with an autonomous, resilient multi-agent network."* |
| **0:15 - 0:45** | • Scroll down to the **Signal Fusion Stream** showing the 8 initial signals (Tweets, Weather API, Maps data, NDMA Sensors, Citizen text).<br/>• Highlight the Urdu tweets ("G-10 mein paani...") and the Rawal Dam rumor. | *"Localized urban crises, such as sudden flash flooding in G-10 and traffic crashes on the Kashmir Highway, occur simultaneously and compete for the same municipal resources.*<br/><br/>*To make matters worse, low-credibility rumors like the Rawal Dam breach circulate on social media, threatening to divert critical emergency resources. Let’s see how CIRO-PK handles this live."* |

---

## Act 2: Architecture & Google Antigravity Integration (0:45 - 1:30)

| Time | Visual on Screen | Voiceover (Audio) |
| --- | --- | --- |
| **0:45 - 1:10** | • Briefly show the **README.md** architecture diagram or the slide explaining the **8 Agents**:<br/>`SIGNAL_FUSION` $\rightarrow$ `CLASSIFIER` $\rightarrow$ `PREDICTOR` $\rightarrow$ `VERIFIER` $\rightarrow$ `ALLOCATOR` $\rightarrow$ `ORCHESTRATOR` $\rightarrow$ `NOTIFIER` $\rightarrow$ `GEMINI_REASONER`. | *"At the core of CIRO-PK is **Google Antigravity (Vertex AI Agent Platform)**. We orchestrate **eight independent Gemini agents** built using the new `google-genai` SDK.*<br/><br/>*Instead of a static script, our pipeline runs structured workflows with parallel stages to ensure real-time response."* |
| **1:10 - 1:30** | • Show the `backend/main.py` code where the `get_client()` caching and tool parameters are defined. | *"We implement global client caching to reuse connection pools, reducing sequential execution latency by up to 2 seconds. We also leverage strict function-calling configurations for structured data extraction."* |

---

## Act 3: Live Execution - Ingestion & Classification (1:30 - 2:40)

| Time | Visual on Screen | Voiceover (Audio) |
| --- | --- | --- |
| **1:30 - 2:00** | • Click the **"INITIATE SIMULATION"** button on the Web Dashboard (or Mobile App).<br/>• Watch the **Agent Trace Log** console update line by line in real-time. | *"Let's trigger the orchestrator. As soon as the cycle starts, the **SIGNAL_FUSION** agent ingests signals across English and Roman Urdu, and fetches live weather data for Islamabad using the OpenWeatherMap API.*<br/><br/>*Immediately after, Stage 1 launches the CLASSIFIER and VERIFIER agents in parallel."* |
| **2:00 - 2:40** | • Hover over the **Map Markers** for C1 (G-10 Flood) and C2 (Faizabad Crash).<br/>• Scroll to the **VERIFIER Log** and show the Rawal Dam rumor being marked as `FALSE_ALARM` (retracted). | *"The CLASSIFIER agent executes the `report_classified_crises` tool, identifying two distinct incidents: a severe Urban Flood in G-10 and a critical crash on the Kashmir Highway.*<br/><br/>*Simultaneously, the VERIFIER agent cross-checks the Rawal Dam rumor against live NDMA sensor telemetry. It detects that the water level is normal, labels the rumor a false alarm, and instantly dispatches a retraction alert to the public, avoiding wasted resources."* |

---

## Act 4: Severity, Resource Allocation & Action Simulation (2:40 - 3:30)

| Time | Visual on Screen | Voiceover (Audio) |
| --- | --- | --- |
| **2:40 - 3:10** | • Show the **Resource Allocator Cards** displaying `6 / 8 Ambulances`, `4 / 5 Rescue Teams`, `10 / 12 Police Units`. | *"Next, the PREDICTOR projects the flood spread, while the ALLOCATOR resolves resource conflicts. Both incidents compete for the same 8 municipal ambulances.*<br/><br/>*The ALLOCATOR calls the `allocate_emergency_resources` tool. It enforces a strict **20% reserve constraint** to keep 2 units available for sudden incidents and distributes the remaining 6, prioritizing the life-threatening road crash."* |
| **3:10 - 3:30** | • Point to the **5 Coordinated Steps** list and the **Notifications section** showing Roman Urdu & English messages. | *"The ORCHESTRATOR then triggers a 5-step response chain: dispatching teams, rerouting traffic (reducing congestion from 340% to 90%), alerting PIMS hospital, shutting off G-10 electricity grids, and sending multilingual SMS alerts to residents."* |

---

## Act 5: Resilience & Final Synthesis (3:30 - 4:00)

| Time | Visual on Screen | Voiceover (Audio) |
| --- | --- | --- |
| **3:30 - 3:50** | • Point to the **GEMINI_REASONER** log trace.<br/>• Show the **Outcome Summary** dashboard badge with green text `GEMINI_LIVE` or `LOCAL_FALLBACK`. | *"Finally, the **GEMINI_REASONER** synthesizes the cycle output into a single executive trace. To ensure the app is bulletproof, we designed a **4-tiered resilience framework**.*<br/><br/>*If the Google Cloud API is unreachable or rate-limited, the system falls back to in-memory deterministic simulation in Python, and further to local browser state simulation if the backend is down."* |
| **3:50 - 4:00** | • Zoom out to show both the Mobile App and the Web Dashboard synchronized.<br/>• End with contact info / thank you screen. | *"CIRO-PK brings real-time, robust, and safe agentic orchestration to urban emergency management. Thank you for your time!"* |

---

## Pro-Tips for Recording the Demo:
1. **Pacing**: Speak slowly, clearly, and enthusiastically. Use a headset mic to filter background noise.
2. **Synchronize**: Record your screen first, edit it to fit the 4-minute timeline, and then record your voiceover to match the video cuts.
3. **Resilience Test**: You can temporarily disable the backend server or block your internet connection to show the UI automatically displaying the "LOCAL_FALLBACK" state. This provides strong proof of system robustness!
