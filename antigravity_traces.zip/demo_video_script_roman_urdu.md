# CIRO-PK: Official Demo Video Script (Roman Urdu Version)
**Target Duration**: ~4 minutes  
**Format**: Screen recording (Web Dashboard + Mobile App) with Roman Urdu Voiceover.

---

## Act 1: Introduction & Problem Statement (0:00 - 0:45)

| Time | Visual on Screen | Voiceover (Audio) |
| --- | --- | --- |
| **0:00 - 0:15** | • **Vite Command Center Dashboard** standby state mein show karein.<br/>• Highlight title **CIRO-PK (Crisis Intelligence & Response Orchestrator)**.<br/>• Islamabad Map par zoom karein. | *"Assalam-o-Alaikum! Hum hain Team Antigravity, aur aaj hum aapko **CIRO-PK** ka demo dikhayenge—jo humne #AISeekho 2026 Hackathon, Challenge 3 ke liye build kiya hai.*<br/><br/>*Humaara maqsad emergency response systems ko autonomous aur multi-agent coordination ke zariye mazeed tezi se respond krne ke kabil banana hai."* |
| **0:15 - 0:45** | • **Signal Fusion Stream** ki taraf scroll karein (8 signals from 5 sources: Tweets, Weather API, Maps, NDMA Sensors, Citizen text).<br/>• G-10 ki flooding aur Rawal Dam wali rumor tweets ko highlight karein. | *"Jab kisi sheher mein ek sath do disasters aate hain—jaise G-10 mein flood aur Kashmir Highway par accident—to resources ki allocation mushkil hojati hai.*<br/><br/>*Iske sath-sath, social media par jhooti afwahain (jaise Rawal Dam breach rumor) aam hojati hain jo resources ko divert krwa sakti hain. Dekhte hain CIRO-PK isko kaise manage krta hai."* |

---

## Act 2: Architecture & Google Antigravity Integration (0:45 - 1:30)

| Time | Visual on Screen | Voiceover (Audio) |
| --- | --- | --- |
| **0:45 - 1:10** | • **README.md** diagram ya **8 Agents** ka flow show karein:<br/>`SIGNAL_FUSION` $\rightarrow$ `CLASSIFIER` $\rightarrow$ `PREDICTOR` $\rightarrow$ `VERIFIER` $\rightarrow$ `ALLOCATOR` $\rightarrow$ `ORCHESTRATOR` $\rightarrow$ `NOTIFIER` $\rightarrow$ `GEMINI_REASONER`. | *"Is poore system ke peeche **Google Antigravity (Vertex AI Agent Platform)** ka core orchestrator kaam kr raha hai.*<br/><br/>*Humne **8 independent Gemini agents** ko `google-genai` SDK ke zariye integrate kiya hai jo parallel stages mein operate krte hain."* |
| **1:10 - 1:30** | • `backend/main.py` code mein `get_client()` caching aur tools check krwain. | *"Behter performance aur fast latency ke liye humne global client caching implement ki hai, taake network delay kam se kam ho. Humne function calling configure ki hai structured telemetry nikalne ke liye."* |

---

## Act 3: Ingestion & Classification Demo (1:30 - 2:40)

| Time | Visual on Screen | Voiceover (Audio) |
| --- | --- | --- |
| **1:30 - 2:00** | • Dashboard par **"INITIATE SIMULATION"** button click karein.<br/>• **Agent Trace Log** console ko real-time update hote hue dekhain. | *"Ab hum simulation initiate krte hain. Subse pehle **SIGNAL_FUSION** agent Roman Urdu aur English tweets ingest krta hai aur live weather update fetch krta hai.*<br/><br/>*Iske baad, Stage 1 mein CLASSIFIER aur VERIFIER agents ek sath parallel chalte hain."* |
| **2:00 - 2:40** | • Map Markers check krwain (C1 and C2).<br/>• **VERIFIER Log** aur Rawal Dam rumor ka status check krwain (FALSE_ALARM - Retracted). | *"CLASSIFIER agent `report_classified_crises` tool call krke do active crises ko detect kr leta hai: G-10 flooding aur Faizabad road accident.*<br/><br/>*Simultaneously, VERIFIER agent Rawal Dam wali jhooti afwah ko NDMA telemetry sensor data se cross-check krta hai. Water level normal hone ki wajah se isko FALSE_ALARM mark krke public retraction dispatch kr deta hai."* |

---

## Act 4: Severity & Resource Allocation (2:40 - 3:30)

| Time | Visual on Screen | Voiceover (Audio) |
| --- | --- | --- |
| **2:40 - 3:10** | • **Resource Allocator Cards** show karein (Ambulances, Rescue Teams, Police Units). | *"Stage 2 mein PREDICTOR flood risk zone predict krta hai aur ALLOCATOR resources distribute krta hai.*<br/><br/>*Dono crises ke beech total 8 ambulances ko balance krte hue, ALLOCATOR **strict 20% reserve constraint** ke mutabiq 2 ambulances safe rakhta hai aur baki 6 mein se critical road accident ko priority deta hai."* |
| **3:10 - 3:30** | • **5 Coordinated Steps** list aur **Notifications** (SMS/Radio alerts in Roman Urdu/English) show karein. | *"Phirr **ORCHESTRATOR** agent 5-step response chain chalata hai: dispatch, traffic rerouting (jis se traffic density 340% se normal par aati hai), hospital alert, IESCO power cutoff, aur local Urdu/English SMS alerts."* |

---

## Act 5: Resilience & Outro (3:30 - 4:00)

| Time | Visual on Screen | Voiceover (Audio) |
| --- | --- | --- |
| **3:30 - 3:50** | • **GEMINI_REASONER** trace log ko highlight karein.<br/>• Dashboard par `LOCAL_FALLBACK` status dikhain. | *"Aakhir mein, **GEMINI_REASONER** senior summary produce krta hai. Humaara system 4-tiered resilience ke sath aata hai.*<br/><br/>*Agar Vertex AI ya internet connection down ho jaye, to system local browser/mobile fallback mode par switch hojata hai aur application crash nahi hoti."* |
| **3:50 - 4:00** | • Mobile App aur Web Dashboard ka comparison screen show karein.<br/>• Final greetings/thanks slide. | *"CIRO-PK emergency response ko dynamic, fast, aur secure banata hai. Demo dekhne ka shukriya!"* |

---

## My Recommendation:
Agar aap video **Roman Urdu** mein de rahe hain, to **English Subtitles (Srt/Captions)** video mein lazmi add karein. Hackathon ke key judges ya Google engineers international teams se ho sakte hain, isliye subtitles unhe poori video aasaani se samjha denge.
